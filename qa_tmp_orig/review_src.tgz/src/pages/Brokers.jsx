import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Building2, Plus, X, Pencil, Trash2, Loader2 } from 'lucide-react';
import StatusBadge from '@/components/StatusBadge';
import DeleteConfirmModal from '@/components/DeleteConfirmModal';
import { useOrganizationId } from '@/lib/AppStateContext';
import { useLanguage } from '@/lib/LanguageContext';
import { listByOrg, withOrg } from '@/lib/orgScope';
import { useProfile } from '@/lib/ProfileContext';
import { useDemo } from '@/lib/DemoContext';
import DemoLimitModal from '@/components/DemoLimitModal';

function ScoreDots({ score, max = 10 }) {
  const filled = Math.round((score || 0));
  const color = filled >= 7 ? 'bg-green-400' : filled >= 5 ? 'bg-yellow-400' : 'bg-red-400';
  return (
    <div className="flex gap-0.5">
      {Array.from({ length: 10 }).map((_, i) => (
        <div key={i} className={`w-2 h-2 rounded-full ${i < filled ? color : 'bg-muted'}`} />
      ))}
    </div>
  );
}

function BrokerForm({ broker, onSave, onClose }) {
  const { t } = useLanguage();
  const { setUnsavedChanges } = useProfile();
  const initialState = {
    nombre: '', mc_number: '', contacto: '', telefono: '', email: '',
    tarifa_promedio: '', dias_pago: 30, puntaje_confiabilidad: 7,
    puntaje_pago: 7, clausulas_frecuentes: '', notas: '', estado: 'activo',
    ...broker
  };
  const [form, setForm] = useState(initialState);
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    const isUnsaved = JSON.stringify(form) !== JSON.stringify(initialState);
    setUnsavedChanges('BrokerForm', isUnsaved);
    return () => setUnsavedChanges('BrokerForm', false);
  }, [form, broker, setUnsavedChanges]);

  const set = (k, v) => setForm(p => ({ ...p, [k]: v }));
  const handleSubmit = async (e) => { 
    e.preventDefault(); 
    if (isSaving) return;
    setIsSaving(true);
    try {
      await onSave(form);
    } finally {
      setIsSaving(false);
    }
  };
  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-card border border-border rounded-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between px-5 py-4 border-b border-border">
          <h2 className="text-base font-semibold">{broker ? t.brokers.edit : t.brokers.new}</h2>
          <button onClick={onClose} disabled={isSaving} className="p-1.5 rounded-lg hover:bg-muted text-muted-foreground"><X className="w-4 h-4" /></button>
        </div>
        <form onSubmit={handleSubmit} className="p-5 space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs text-muted-foreground mb-1 block">{t.brokers.name} *</label>
              <input required maxLength={80} value={form.nombre} onChange={e => set('nombre', e.target.value)}
                className="w-full bg-muted border border-border rounded-lg px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary/50" />
            </div>
            <div>
              <label className="text-xs text-muted-foreground mb-1 block">MC Number</label>
              <input value={form.mc_number} onChange={e => set('mc_number', e.target.value)}
                className="w-full bg-muted border border-border rounded-lg px-3 py-2 text-sm text-foreground font-mono focus:outline-none focus:ring-1 focus:ring-primary/50" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs text-muted-foreground mb-1 block">{t.brokers.contact}</label>
              <input value={form.contacto} onChange={e => set('contacto', e.target.value)}
                className="w-full bg-muted border border-border rounded-lg px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary/50" />
            </div>
            <div>
              <label className="text-xs text-muted-foreground mb-1 block">{t.brokers.phone}</label>
              <input value={form.telefono} onChange={e => set('telefono', e.target.value)}
                className="w-full bg-muted border border-border rounded-lg px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary/50" />
            </div>
          </div>
          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="text-xs text-muted-foreground mb-1 block">{t.brokers.avgRate}</label>
              <input type="number" step="0.01" value={form.tarifa_promedio} onChange={e => set('tarifa_promedio', Number(e.target.value))}
                className="w-full bg-muted border border-border rounded-lg px-3 py-2 text-sm text-foreground font-mono focus:outline-none focus:ring-1 focus:ring-primary/50" />
            </div>
            <div>
              <label className="text-xs text-muted-foreground mb-1 block">{t.brokers.paymentDays}</label>
              <input type="number" value={form.dias_pago} onChange={e => set('dias_pago', Number(e.target.value))}
                className="w-full bg-muted border border-border rounded-lg px-3 py-2 text-sm text-foreground font-mono focus:outline-none focus:ring-1 focus:ring-primary/50" />
            </div>
            <div>
              <label className="text-xs text-muted-foreground mb-1 block">{t.brokers.status}</label>
              <select value={form.estado} onChange={e => set('estado', e.target.value)}
                className="w-full bg-muted border border-border rounded-lg px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary/50">
                {['activo','precaucion','bloqueado'].map(s => <option key={s} value={s}>{t.statuses?.[s] || s}</option>)}
              </select>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs text-muted-foreground mb-1 block">{t.brokers.reliability}</label>
              <input type="number" min="1" max="10" value={form.puntaje_confiabilidad} onChange={e => set('puntaje_confiabilidad', Number(e.target.value))}
                className="w-full bg-muted border border-border rounded-lg px-3 py-2 text-sm text-foreground font-mono focus:outline-none focus:ring-1 focus:ring-primary/50" />
            </div>
            <div>
              <label className="text-xs text-muted-foreground mb-1 block">{t.brokers.timelyPayment}</label>
              <input type="number" min="1" max="10" value={form.puntaje_pago} onChange={e => set('puntaje_pago', Number(e.target.value))}
                className="w-full bg-muted border border-border rounded-lg px-3 py-2 text-sm text-foreground font-mono focus:outline-none focus:ring-1 focus:ring-primary/50" />
            </div>
          </div>
          <div>
            <label className="text-xs text-muted-foreground mb-1 block">{t.brokers.clauses}</label>
            <textarea value={form.clausulas_frecuentes} onChange={e => set('clausulas_frecuentes', e.target.value)} rows={2}
              className="w-full bg-muted border border-border rounded-lg px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary/50 resize-none" />
          </div>
          <div>
            <label className="text-xs text-muted-foreground mb-1 block">{t.brokers.notes}</label>
            <textarea value={form.notas} onChange={e => set('notas', e.target.value)} rows={2}
              className="w-full bg-muted border border-border rounded-lg px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary/50 resize-none" />
          </div>
          <div className="flex gap-2 pt-1">
            <button type="button" onClick={onClose} disabled={isSaving} className="flex-1 py-2 rounded-xl border border-border text-sm text-muted-foreground hover:text-foreground disabled:opacity-40">{t.brokers.cancel}</button>
            <button type="submit" disabled={isSaving} className="flex-1 py-2 rounded-xl bg-primary text-sm font-semibold text-primary-foreground disabled:opacity-50 flex items-center justify-center gap-2">
              {isSaving ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>{t.brokers.save}...</span>
                </>
              ) : (
                t.brokers.save
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default function Brokers() {
  const { t, locale } = useLanguage();
  const orgId = useOrganizationId();
  const { activeProfileId } = useProfile();
  const { isDemoUser, limits } = useDemo();
  const [brokers, setBrokers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [showLimitModal, setShowLimitModal] = useState(false);
  const [editBroker, setEditBroker] = useState(null);
  const [deleteBroker, setDeleteBroker] = useState(null);
  const [deleteLoading, setDeleteLoading] = useState(false);

  const handleDeleteBroker = async () => {
    if (!deleteBroker) return;
    try {
      setDeleteLoading(true);
      await base44.entities.Broker.delete(deleteBroker.id);
      const key = `profile_brokers_${orgId}_${activeProfileId}`;
      const current = getProfileBrokerIds() || [];
      localStorage.setItem(key, JSON.stringify(current.filter(id => id !== deleteBroker.id)));
      setDeleteBroker(null);
      loadData();
    } catch (err) {
      console.error('Error eliminando broker:', err);
      alert('Error al eliminar: ' + (err?.message || 'intente de nuevo'));
    } finally {
      setDeleteLoading(false);
    }
  };

  const getProfileBrokerIds = () => {
    const key = `profile_brokers_${orgId}_${activeProfileId}`;
    const stored = localStorage.getItem(key);
    return stored ? JSON.parse(stored) : null;
  };

  const addBrokerToProfile = (brokerId) => {
    const key = `profile_brokers_${orgId}_${activeProfileId}`;
    const current = getProfileBrokerIds() || [];
    localStorage.setItem(key, JSON.stringify([...current, brokerId]));
  };

  const loadData = async () => {
    setLoading(true);
    const data = await listByOrg(base44.entities.Broker, orgId);
    const profileIds = getProfileBrokerIds();

    let filtered;
    if (activeProfileId === '1' && profileIds === null) {
      const usedIds = [];
      for (let i = 2; i <= 5; i++) {
        const stored = localStorage.getItem(`profile_brokers_${orgId}_${i}`);
        if (stored) usedIds.push(...JSON.parse(stored));
      }
      const unclaimed = data.filter(b => (!b.profile_id || b.profile_id === '1') && !usedIds.includes(b.id));
      const unclaimedIds = unclaimed.map(b => b.id);
      localStorage.setItem(`profile_brokers_${orgId}_1`, JSON.stringify(unclaimedIds));
      filtered = data.filter(b => b.profile_id === '1' || unclaimedIds.includes(b.id));

      // Fase 5: Migración silenciosa en BD para backfill de profile_id = '1'
      unclaimed.forEach(b => {
        if (!b.profile_id) {
          base44.entities.Broker.update(b.id, { profile_id: '1' }).catch(() => {});
        }
      });
    } else {
      filtered = data.filter(b => {
        if (b.profile_id) return b.profile_id === activeProfileId;
        return profileIds && profileIds.includes(b.id);
      });

      // Si estaba en localStorage de este perfil pero sin profile_id en BD, migrar
      filtered.forEach(b => {
        if (!b.profile_id) {
          base44.entities.Broker.update(b.id, { profile_id: activeProfileId }).catch(() => {});
        }
      });
    }

    setBrokers(filtered);
    setLoading(false);
  };
  useEffect(() => { loadData(); }, [orgId, activeProfileId]);

  const handleSave = async (data) => {
    try {
      if (editBroker) {
        await base44.entities.Broker.update(editBroker.id, {
          ...data,
          profile_id: editBroker.profile_id || activeProfileId || '1',
        });
      } else {
        const created = await base44.entities.Broker.create(
          withOrg(orgId, {
            ...data,
            profile_id: activeProfileId || '1',
          })
        );
        addBrokerToProfile(created.id);
      }
      setShowForm(false); setEditBroker(null); loadData();
    } catch (err) {
      console.error('Error guardando broker:', err);
      alert('Error al guardar: ' + (err?.message || 'intente de nuevo'));
    }
  };

  return (
    <div className="p-4 md:p-6 space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-foreground">{t.brokers.title}</h1>
          <p className="text-sm text-muted-foreground">{brokers.length} {t.brokers.registered}</p>
        </div>
        <button onClick={() => {
          if (limits?.BROKERS && brokers.length >= limits.BROKERS) {
            setShowLimitModal(true);
            return;
          }
          setEditBroker(null); 
          setShowForm(true); 
        }}
          className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-primary hover:bg-primary/90 text-xs font-semibold text-primary-foreground">
          <Plus className="w-3.5 h-3.5" />{t.brokers.add}
        </button>
      </div>

      <DemoLimitModal
        isOpen={showLimitModal}
        onClose={() => setShowLimitModal(false)}
        entityName="brokers"
        currentCount={brokers.length}
        maxLimit={limits?.BROKERS || 5}
      />

      {showForm && <BrokerForm broker={editBroker} onSave={handleSave} onClose={() => { setShowForm(false); setEditBroker(null); }} />}

      {loading ? (
        <div className="flex justify-center py-12"><div className="w-6 h-6 border-2 border-primary border-t-transparent rounded-full animate-spin" /></div>
      ) : brokers.length === 0 ? (
        <div className="text-center py-12 text-muted-foreground">
          <Building2 className="w-8 h-8 mx-auto mb-2 opacity-40" />
          <p className="text-sm">{t.brokers.noBrokers}</p>
        </div>
      ) : (
        <div className="bg-card border border-border rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="border-b border-border">
                <tr className="text-xs text-muted-foreground">
                  <th className="text-left px-4 py-3 font-medium">Broker</th>
                  <th className="text-center px-4 py-3 font-medium hidden sm:table-cell">{t.brokers.loads}</th>
                  <th className="text-right px-4 py-3 font-medium hidden sm:table-cell">{t.brokers.avgRateShort}</th>
                  <th className="text-right px-4 py-3 font-medium hidden md:table-cell">{t.brokers.payDays}</th>
                  <th className="text-left px-4 py-3 font-medium hidden md:table-cell">{t.brokers.reliability}</th>
                  <th className="text-left px-4 py-3 font-medium hidden lg:table-cell">{t.brokers.timelyPayment}</th>
                  <th className="text-left px-4 py-3 font-medium">{t.brokers.status}</th>
                  <th className="px-4 py-3"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border/50">
                {brokers.sort((a, b) => (b.cargas_realizadas || 0) - (a.cargas_realizadas || 0)).map(broker => (
                  <tr key={broker.id} className="hover:bg-muted/20 transition-colors">
                    <td className="px-4 py-3">
                      <div className="font-medium text-foreground truncate max-w-[16rem] sm:max-w-xs" title={broker.nombre}>{broker.nombre}</div>
                      <div className="text-xs text-muted-foreground">{broker.mc_number || t.brokers.noMc} · {broker.contacto || t.brokers.noContact}</div>
                      {broker.clausulas_frecuentes && (
                        <div className="text-xs text-yellow-400 mt-0.5 truncate max-w-48">⚠ {broker.clausulas_frecuentes}</div>
                      )}
                    </td>
                    <td className="px-4 py-3 text-center text-foreground font-mono hidden sm:table-cell">{broker.cargas_realizadas || 0}</td>
                    <td className={`px-4 py-3 text-right font-mono font-semibold hidden sm:table-cell ${
                      (broker.tarifa_promedio || 0) >= 3 ? 'text-green-400' : (broker.tarifa_promedio || 0) >= 2.6 ? 'text-yellow-400' : 'text-red-400'
                    }`}>${broker.tarifa_promedio?.toFixed(2) || '--'}</td>
                    <td className="px-4 py-3 text-right text-muted-foreground hidden md:table-cell">Net {broker.dias_pago || '--'}</td>
                    <td className="px-4 py-3 hidden md:table-cell">
                      <ScoreDots score={broker.puntaje_confiabilidad} />
                      <span className="text-xs text-muted-foreground">{broker.puntaje_confiabilidad || '--'}/10</span>
                    </td>
                    <td className="px-4 py-3 hidden lg:table-cell">
                      <ScoreDots score={broker.puntaje_pago} />
                      <span className="text-xs text-muted-foreground">{broker.puntaje_pago || '--'}/10</span>
                    </td>
                    <td className="px-4 py-3"><StatusBadge status={broker.estado} /></td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1 justify-end">
                        <button onClick={() => { setEditBroker(broker); setShowForm(true); }}
                          className="p-1.5 rounded-lg hover:bg-muted text-muted-foreground hover:text-foreground"
                          title={locale === 'en' ? 'Edit' : 'Editar'}>
                          <Pencil className="w-3.5 h-3.5" />
                        </button>
                        <button onClick={() => setDeleteBroker(broker)}
                          className="p-1.5 rounded-lg hover:bg-red-500/10 text-muted-foreground hover:text-red-400 transition-colors"
                          title={locale === 'en' ? 'Delete' : 'Eliminar'}>
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      <DeleteConfirmModal
        isOpen={!!deleteBroker}
        title={locale === 'en' ? 'Do you want to delete this Broker?' : '¿Desea eliminar el Broker?'}
        subtitle={deleteBroker?.nombre || ''}
        onConfirm={handleDeleteBroker}
        onClose={() => setDeleteBroker(null)}
        loading={deleteLoading}
        confirmText={locale === 'en' ? 'Delete' : 'Eliminar'}
        cancelText={locale === 'en' ? 'Cancel' : 'Cancelar'}
      />
    </div>
  );
}