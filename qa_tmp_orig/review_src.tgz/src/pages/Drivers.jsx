import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Users, Plus, X, Pencil, Trash2, AlertTriangle, CheckCircle2, Loader2 } from 'lucide-react';
import StatusBadge from '@/components/StatusBadge';
import DeleteConfirmModal from '@/components/DeleteConfirmModal';
import { useOrganizationId } from '@/lib/AppStateContext';
import { useLanguage } from '@/lib/LanguageContext';
import { useProfile } from '@/lib/ProfileContext';
import { listByOrg, withOrg } from '@/lib/orgScope';
import { useDemo } from '@/lib/DemoContext';
import DemoLimitModal from '@/components/DemoLimitModal';

function DocAlert({ label, date }) {
  const { t } = useLanguage();
  if (!date) return null;
  const today = new Date();
  const exp = new Date(date);
  const diff = Math.floor((exp.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
  if (diff > 60) return null;
  const expired = diff < 0;
  return (
    <div className={`flex items-center gap-1.5 text-xs px-2 py-1 rounded-md ${expired ? 'bg-red-400/10 text-red-400' : 'bg-yellow-400/10 text-yellow-400'}`}>
      <AlertTriangle className="w-3 h-3 flex-shrink-0" />
      {label}: {expired ? `${t.drivers.expired} ${Math.abs(diff)}d` : `${t.drivers.expiresIn} ${diff}d`}
    </div>
  );
}

function DriverForm({ driver, onSave, onClose, existingDrivers = [] }) {
  const { t, locale } = useLanguage();
  const isEs = locale !== 'en';
  const [formError, setFormError] = useState('');
  const { setUnsavedChanges } = useProfile();
  const initialState = {
    nombre: '', apellido: '', telefono: '', licencia_numero: '',
    licencia_vencimiento: '', medico_vencimiento: '', twic_vencimiento: '',
    hazmat_vencimiento: '', estado: 'activo', truck_asignado: '', notas: '',
    ...driver
  };
  const [form, setForm] = useState(initialState);
  const [isSaving, setIsSaving] = useState(false);
  
  useEffect(() => {
    const isUnsaved = JSON.stringify(form) !== JSON.stringify(initialState);
    setUnsavedChanges('DriverForm', isUnsaved);
    return () => setUnsavedChanges('DriverForm', false);
  }, [form, driver, setUnsavedChanges]);

  const set = (k, v) => setForm(p => ({ ...p, [k]: v }));
  const handleSubmit = async (e) => { 
    e.preventDefault(); 
    if (isSaving) return;

    // M3 (QA): teléfono válido (7 a 15 dígitos; se permiten + ( ) - . y espacios)
    const phone = String(form.telefono || '').trim();
    if (phone) {
      const digits = phone.replace(/\D/g, '');
      if (!/^[0-9+()\-.\s]+$/.test(phone) || digits.length < 7 || digits.length > 15) {
        setFormError(isEs ? 'Teléfono inválido: usa solo números (7 a 15 dígitos).' : 'Invalid phone: use numbers only (7 to 15 digits).');
        return;
      }
    }
    // M3 (QA): evitar duplicados (misma licencia, o mismo nombre + teléfono)
    const norm = (v) => String(v || '').toLowerCase().replace(/\s+/g, ' ').trim();
    const onlyDigits = (v) => String(v || '').replace(/\D/g, '');
    const fullName = norm(`${form.nombre} ${form.apellido}`);
    const dup = existingDrivers.find(d => d.id !== driver?.id && (
      (norm(form.licencia_numero) && norm(d.licencia_numero) === norm(form.licencia_numero)) ||
      (fullName && norm(`${d.nombre} ${d.apellido}`) === fullName && onlyDigits(d.telefono) === onlyDigits(form.telefono))
    ));
    if (dup) {
      setFormError(isEs
        ? `Ya existe un conductor con esos datos: ${`${dup.nombre || ''} ${dup.apellido || ''}`.trim()}.`
        : `A driver with that data already exists: ${`${dup.nombre || ''} ${dup.apellido || ''}`.trim()}.`);
      return;
    }
    setFormError('');
    setIsSaving(true);
    try {
      await onSave(form);
    } finally {
      setIsSaving(false);
    }
  };
  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-card border border-border rounded-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between px-5 py-4 border-b border-border">
          <h2 className="text-base font-semibold">{driver ? t.drivers.edit : t.drivers.new}</h2>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-muted text-muted-foreground"><X className="w-4 h-4" /></button>
        </div>
        <form onSubmit={handleSubmit} className="p-5 space-y-3">
          {formError && (
            <div className="p-2.5 rounded-lg border border-red-500/40 bg-red-500/10 text-xs text-red-300">{formError}</div>
          )}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs text-muted-foreground mb-1 block">{t.drivers.name} *</label>
              <input required value={form.nombre} onChange={e => set('nombre', e.target.value)}
                className="w-full bg-muted border border-border rounded-lg px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary/50" />
            </div>
            <div>
              <label className="text-xs text-muted-foreground mb-1 block">{t.drivers.lastName}</label>
              <input value={form.apellido} onChange={e => set('apellido', e.target.value)}
                className="w-full bg-muted border border-border rounded-lg px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary/50" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs text-muted-foreground mb-1 block">{t.drivers.phone}</label>
              <input type="tel" inputMode="tel" value={form.telefono} onChange={e => { set('telefono', e.target.value); setFormError(''); }}
                className="w-full bg-muted border border-border rounded-lg px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary/50" />
            </div>
            <div>
              <label className="text-xs text-muted-foreground mb-1 block">{t.drivers.status}</label>
              <select value={form.estado} onChange={e => set('estado', e.target.value)}
                className="w-full bg-muted border border-border rounded-lg px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary/50">
                {['activo','inactivo','vacaciones','suspension'].map(s => <option key={s} value={s}>{t.statuses?.[s] || s}</option>)}
              </select>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs text-muted-foreground mb-1 block">{t.drivers.license}</label>
              <input value={form.licencia_numero} onChange={e => set('licencia_numero', e.target.value)}
                className="w-full bg-muted border border-border rounded-lg px-3 py-2 text-sm text-foreground font-mono focus:outline-none focus:ring-1 focus:ring-primary/50" />
            </div>
            <div>
              <label className="text-xs text-muted-foreground mb-1 block">{t.drivers.licenseExpiry}</label>
              <input type="date" value={form.licencia_vencimiento} onChange={e => set('licencia_vencimiento', e.target.value)}
                className="w-full bg-muted border border-border rounded-lg px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary/50" />
            </div>
          </div>
          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="text-xs text-muted-foreground mb-1 block">{t.drivers.medicalExpiry}</label>
              <input type="date" value={form.medico_vencimiento} onChange={e => set('medico_vencimiento', e.target.value)}
                className="w-full bg-muted border border-border rounded-lg px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary/50" />
            </div>
            <div>
              <label className="text-xs text-muted-foreground mb-1 block">{t.drivers.twicExpiry}</label>
              <input type="date" value={form.twic_vencimiento} onChange={e => set('twic_vencimiento', e.target.value)}
                className="w-full bg-muted border border-border rounded-lg px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary/50" />
            </div>
            <div>
              <label className="text-xs text-muted-foreground mb-1 block">{t.drivers.hazmatExpiry}</label>
              <input type="date" value={form.hazmat_vencimiento} onChange={e => set('hazmat_vencimiento', e.target.value)}
                className="w-full bg-muted border border-border rounded-lg px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary/50" />
            </div>
          </div>
          <div>
            <label className="text-xs text-muted-foreground mb-1 block">{t.drivers.assignedTruck}</label>
            <input value={form.truck_asignado} onChange={e => set('truck_asignado', e.target.value)}
              className="w-full bg-muted border border-border rounded-lg px-3 py-2 text-sm text-foreground font-mono focus:outline-none focus:ring-1 focus:ring-primary/50" />
          </div>
          <div>
            <label className="text-xs text-muted-foreground mb-1 block">{t.drivers.notes}</label>
            <textarea value={form.notas} onChange={e => set('notas', e.target.value)} rows={2}
              className="w-full bg-muted border border-border rounded-lg px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary/50 resize-none" />
          </div>
          <div className="flex gap-2 pt-1">
            <button type="button" onClick={onClose} disabled={isSaving} className="flex-1 py-2 rounded-xl border border-border text-sm text-muted-foreground hover:text-foreground disabled:opacity-40">{t.drivers.cancel}</button>
            <button type="submit" disabled={isSaving} className="flex-1 py-2 rounded-xl bg-primary text-sm font-semibold text-primary-foreground disabled:opacity-50 flex items-center justify-center gap-2">
              {isSaving ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>{t.drivers.save}...</span>
                </>
              ) : (
                t.drivers.save
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default function Drivers() {
  const { t, locale } = useLanguage();
  const orgId = useOrganizationId();
  const { activeProfileId } = useProfile();
  const { isDemoUser, limits } = useDemo();
  const [drivers, setDrivers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [showLimitModal, setShowLimitModal] = useState(false);
  const [editDriver, setEditDriver] = useState(null);
  const [deleteDriver, setDeleteDriver] = useState(null);
  const [deleteLoading, setDeleteLoading] = useState(false);

  const handleDeleteDriver = async () => {
    if (!deleteDriver) return;
    try {
      setDeleteLoading(true);
      await base44.entities.Driver.delete(deleteDriver.id);
      const key = `profile_drivers_${orgId}_${activeProfileId}`;
      const current = getProfileDriverIds() || [];
      localStorage.setItem(key, JSON.stringify(current.filter(id => id !== deleteDriver.id)));
      setDeleteDriver(null);
      loadData();
    } catch (err) {
      console.error('Error eliminando conductor:', err);
      alert('Error al eliminar: ' + (err?.message || 'intente de nuevo'));
    } finally {
      setDeleteLoading(false);
    }
  };

  /**
   * Obtener los IDs de conductores que pertenecen al perfil activo,
   * desde el localStorage (no tocamos el schema de base44 en Fase 1).
   */
  const getProfileDriverIds = () => {
    const key = `profile_drivers_${orgId}_${activeProfileId}`;
    const stored = localStorage.getItem(key);
    return stored ? JSON.parse(stored) : null; // null = perfil sin restricciones todavía (Perfil 1 heredado)
  };

  const addDriverToProfile = (driverId) => {
    const key = `profile_drivers_${orgId}_${activeProfileId}`;
    const current = getProfileDriverIds() || [];
    localStorage.setItem(key, JSON.stringify([...current, driverId]));
  };

  const loadData = async () => {
    setLoading(true);
    const data = await listByOrg(base44.entities.Driver, orgId);
    const profileIds = getProfileDriverIds();
    
    let filtered;
    if (activeProfileId === '1' && profileIds === null) {
      // Perfil 1 sin lista: inicializamos su lista con todos los IDs que NO pertenezcan a otros perfiles
      const usedIds = [];
      for (let i = 2; i <= 5; i++) {
        const stored = localStorage.getItem(`profile_drivers_${orgId}_${i}`);
        if (stored) usedIds.push(...JSON.parse(stored));
      }
      const unclaimed = data.filter(d => (!d.profile_id || d.profile_id === '1') && !usedIds.includes(d.id));
      const unclaimedIds = unclaimed.map(d => d.id);
      const key = `profile_drivers_${orgId}_1`;
      localStorage.setItem(key, JSON.stringify(unclaimedIds));
      filtered = data.filter(d => d.profile_id === '1' || unclaimedIds.includes(d.id));

      // Fase 5: Migración silenciosa en BD para backfill de profile_id = '1'
      unclaimed.forEach(d => {
        if (!d.profile_id) {
          base44.entities.Driver.update(d.id, { profile_id: '1' }).catch(() => {});
        }
      });
    } else {
      filtered = data.filter(d => {
        if (d.profile_id) return d.profile_id === activeProfileId;
        return profileIds && profileIds.includes(d.id);
      });

      // Si estaba en localStorage de este perfil pero sin profile_id en BD, migrar
      filtered.forEach(d => {
        if (!d.profile_id) {
          base44.entities.Driver.update(d.id, { profile_id: activeProfileId }).catch(() => {});
        }
      });
    }
    
    setDrivers(filtered);
    setLoading(false);
  };
  useEffect(() => { loadData(); }, [orgId, activeProfileId]);

  const handleSave = async (data) => {
    try {
      let targetId;
      if (editDriver) {
        await base44.entities.Driver.update(editDriver.id, {
          ...data,
          profile_id: editDriver.profile_id || activeProfileId || '1',
        });
        targetId = editDriver.id;
      } else {
        const created = await base44.entities.Driver.create(
          withOrg(orgId, {
            ...data,
            profile_id: activeProfileId || '1',
          })
        );
        addDriverToProfile(created.id);
        targetId = created.id;
      }

      // Notificar a los observadores de alertas operacionales
      window.dispatchEvent(new CustomEvent('notifications-updated'));

      setShowForm(false); setEditDriver(null); loadData();
    } catch (err) {
      console.error('Error guardando conductor:', err);
      alert('Error al guardar: ' + (err?.message || 'intente de nuevo'));
    }
  };

  return (
    <div className="p-4 md:p-6 space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-foreground">{t.drivers.title}</h1>
          <p className="text-sm text-muted-foreground">{drivers.length} {t.drivers.registered}</p>
        </div>
        <button onClick={() => {
          if (limits?.DRIVERS && drivers.length >= limits.DRIVERS) {
            setShowLimitModal(true);
            return;
          }
          setEditDriver(null); 
          setShowForm(true); 
        }}
          className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-primary hover:bg-primary/90 text-xs font-semibold text-primary-foreground">
          <Plus className="w-3.5 h-3.5" />{t.drivers.add}
        </button>
      </div>

      <DemoLimitModal
        isOpen={showLimitModal}
        onClose={() => setShowLimitModal(false)}
        entityName="conductores"
        currentCount={drivers.length}
        maxLimit={limits?.DRIVERS || 5}
      />

      {showForm && <DriverForm driver={editDriver} existingDrivers={drivers} onSave={handleSave} onClose={() => { setShowForm(false); setEditDriver(null); }} />}

      {loading ? (
        <div className="flex justify-center py-12"><div className="w-6 h-6 border-2 border-primary border-t-transparent rounded-full animate-spin" /></div>
      ) : drivers.length === 0 ? (
        <div className="text-center py-12 text-muted-foreground">
          <Users className="w-8 h-8 mx-auto mb-2 opacity-40" />
          <p className="text-sm">{t.drivers.noDrivers}</p>
        </div>
      ) : (
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {drivers.map(driver => (
            <div key={driver.id} className="bg-card border border-border rounded-xl p-4 hover:border-primary/30 transition-colors">
              <div className="flex items-start justify-between mb-2">
                <div>
                  <div className="font-semibold text-foreground">{driver.nombre} {driver.apellido || ''}</div>
                  <div className="text-xs text-muted-foreground mt-0.5">{driver.telefono || t.drivers.noPhone}</div>
                </div>
                <div className="flex items-center gap-1.5">
                  <StatusBadge status={driver.estado} />
                  <button onClick={() => { setEditDriver(driver); setShowForm(true); }}
                    className="p-1.5 rounded-lg hover:bg-muted text-muted-foreground hover:text-foreground"
                    title={locale === 'en' ? 'Edit' : 'Editar'}>
                    <Pencil className="w-3 h-3" />
                  </button>
                  <button onClick={() => setDeleteDriver(driver)}
                    className="p-1.5 rounded-lg hover:bg-red-500/10 text-muted-foreground hover:text-red-400 transition-colors"
                    title={locale === 'en' ? 'Delete' : 'Eliminar'}>
                    <Trash2 className="w-3 h-3" />
                  </button>
                </div>
              </div>
              {driver.truck_asignado && (
                <div className="text-xs text-muted-foreground mb-2">Camión: <span className="text-foreground font-mono">{driver.truck_asignado}</span></div>
              )}
              <div className="space-y-1">
                <DocAlert label={locale === 'en' ? 'License' : 'Licencia'} date={driver.licencia_vencimiento} />
                <DocAlert label={locale === 'en' ? 'Medical' : 'Médico'} date={driver.medico_vencimiento} />
                <DocAlert label="TWIC" date={driver.twic_vencimiento} />
                <DocAlert label="HazMat" date={driver.hazmat_vencimiento} />
                {!driver.licencia_vencimiento && !driver.medico_vencimiento && !driver.twic_vencimiento && (
                  <div className="flex items-center gap-1 text-xs text-green-400">
                    <CheckCircle2 className="w-3 h-3" />
                    {t.drivers.documentsOk}
                  </div>
                )}
              </div>
              {driver.notas && <p className="text-xs text-muted-foreground/70 italic mt-2 truncate">{driver.notas}</p>}
            </div>
          ))}
        </div>
      )}

      <DeleteConfirmModal
        isOpen={!!deleteDriver}
        title={locale === 'en' ? 'Do you want to delete this Driver?' : '¿Desea eliminar el Conductor?'}
        subtitle={deleteDriver ? `${deleteDriver.nombre} ${deleteDriver.apellido || ''}` : ''}
        onConfirm={handleDeleteDriver}
        onClose={() => setDeleteDriver(null)}
        loading={deleteLoading}
        confirmText={locale === 'en' ? 'Delete' : 'Eliminar'}
        cancelText={locale === 'en' ? 'Cancel' : 'Cancelar'}
      />
    </div>
  );
}