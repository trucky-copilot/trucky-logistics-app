import { CheckCircle2, AlertTriangle, XCircle, FileCheck, History, Zap } from 'lucide-react';
import { useLanguage } from '@/lib/LanguageContext';

export default function ResultHeader({ analysis, onLinkToLoad, cached }) {
  const { t, locale } = useLanguage();

  const VEREDICTO_CONFIG = {
    'Aceptar': { color: 'text-green-400', bg: 'bg-green-400/10', border: 'border-green-400/30', icon: CheckCircle2, label: locale === 'en' ? 'ACCEPT' : 'ACEPTAR', riesgo: locale === 'en' ? 'Low' : 'Bajo' },
    'Accept': { color: 'text-green-400', bg: 'bg-green-400/10', border: 'border-green-400/30', icon: CheckCircle2, label: locale === 'en' ? 'ACCEPT' : 'ACEPTAR', riesgo: locale === 'en' ? 'Low' : 'Bajo' },
    'Revisar antes de aceptar': { color: 'text-yellow-400', bg: 'bg-yellow-400/10', border: 'border-yellow-400/30', icon: AlertTriangle, label: locale === 'en' ? 'REVIEW' : 'REVISAR', riesgo: locale === 'en' ? 'Medium' : 'Medio' },
    'Review before accepting': { color: 'text-yellow-400', bg: 'bg-yellow-400/10', border: 'border-yellow-400/30', icon: AlertTriangle, label: locale === 'en' ? 'REVIEW' : 'REVISAR', riesgo: locale === 'en' ? 'Medium' : 'Medio' },
    'Negociar': { color: 'text-yellow-400', bg: 'bg-yellow-400/10', border: 'border-yellow-400/30', icon: AlertTriangle, label: locale === 'en' ? 'NEGOTIATE' : 'NEGOCIAR', riesgo: locale === 'en' ? 'Medium' : 'Medio' },
    'Negotiate': { color: 'text-yellow-400', bg: 'bg-yellow-400/10', border: 'border-yellow-400/30', icon: AlertTriangle, label: locale === 'en' ? 'NEGOTIATE' : 'NEGOCIAR', riesgo: locale === 'en' ? 'Medium' : 'Medio' },
    'No aceptar hasta corregir': { color: 'text-red-400', bg: 'bg-red-400/10', border: 'border-red-400/30', icon: XCircle, label: locale === 'en' ? 'DO NOT ACCEPT' : 'NO ACEPTAR', riesgo: locale === 'en' ? 'High' : 'Alto' },
    'Do not accept until corrected': { color: 'text-red-400', bg: 'bg-red-400/10', border: 'border-red-400/30', icon: XCircle, label: locale === 'en' ? 'DO NOT ACCEPT' : 'NO ACEPTAR', riesgo: locale === 'en' ? 'High' : 'Alto' },
  };

  const RESUMEN_CORTO = {
    'Aceptar': locale === 'en' ? 'Correct document for operations' : 'Documento correcto para operar',
    'Accept': locale === 'en' ? 'Correct document for operations' : 'Documento correcto para operar',
    'Revisar antes de aceptar': locale === 'en' ? 'Requires review before accepting' : 'Requiere revisión antes de aceptar',
    'Review before accepting': locale === 'en' ? 'Requires review before accepting' : 'Requiere revisión antes de aceptar',
    'Negociar': locale === 'en' ? 'There are conditions to adjust' : 'Hay condiciones que deben ajustarse',
    'Negotiate': locale === 'en' ? 'There are conditions to adjust' : 'Hay condiciones que deben ajustarse',
    'No aceptar hasta corregir': locale === 'en' ? 'There are major inconsistencies' : 'Hay inconsistencias importantes',
    'Do not accept until corrected': locale === 'en' ? 'There are major inconsistencies' : 'Hay inconsistencias importantes',
  };


  const DOC_LABEL = {
    rate_confirmation: 'Rate Confirmation',
    delivery_order: 'Delivery Order',
  };

  const v = VEREDICTO_CONFIG[analysis.veredicto] || VEREDICTO_CONFIG['Negociar'];
  const Icon = v.icon;
  const docLabel = DOC_LABEL[analysis.datos_extraidos?.tipo_documento] || analysis.datos_extraidos?.tipo_documento || 'Documento';
  const resumenCorto = RESUMEN_CORTO[analysis.veredicto] || analysis.resumen_ejecutivo;
  const isCache = cached || analysis.analysis_source === 'cache';
  const isNew = !isCache;

  return (
    <div className={`rounded-2xl border ${v.border} ${v.bg} overflow-hidden`}>
      {/* Top bar con tipo de documento */}
      <div className="flex items-center gap-2 px-4 py-2 border-b border-white/5 bg-black/10">
        <FileCheck className="w-3.5 h-3.5 text-muted-foreground flex-shrink-0" />
        <span className="text-xs text-muted-foreground font-medium">{docLabel}</span>
        {isNew && (
          <span className="flex items-center gap-1 text-[10px] font-bold text-green-400 bg-green-400/10 px-1.5 py-0.5 rounded-full border border-green-400/20">
            <Zap className="w-2.5 h-2.5" /> {t.documents.newAnalysis}
          </span>
        )}
        {isCache && (
          <span className="flex items-center gap-1 text-[10px] font-bold text-primary bg-primary/10 px-1.5 py-0.5 rounded-full border border-primary/20">
            <History className="w-2.5 h-2.5" /> {t.documents.fromCache}
          </span>
        )}
        {isCache && (
          <span className="text-[10px] text-muted-foreground hidden sm:inline">
            {locale === 'en'
              ? 'Same document · same user · same configuration · same rules'
              : 'Mismo documento · mismo usuario · misma configuración · mismas reglas'}
          </span>
        )}
        {analysis.confidence_score != null && (
          <>
            <span className="text-border mx-1">·</span>
              <span className="text-xs text-muted-foreground">{t.documents.confidence} <span className="font-semibold text-foreground">{analysis.confidence_score}%</span></span>
          </>
        )}
        {analysis.carrier_profile_used && (
          <>
            <span className="text-border mx-1">·</span>
            <span className="text-xs text-muted-foreground truncate">Carrier: <span className="font-semibold text-foreground">{analysis.carrier_profile_used}</span></span>
          </>
        )}
      </div>

      {/* Veredicto principal */}
      <div className="p-5">
        <div className="flex items-start gap-4">
          <div className={`w-14 h-14 rounded-2xl border-2 ${v.border} bg-black/20 flex items-center justify-center flex-shrink-0`}>
            <Icon className={`w-7 h-7 ${v.color}`} />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <span className={`text-2xl font-black tracking-tight ${v.color}`}>{v.label}</span>
              <span className={`text-xs font-bold px-2 py-0.5 rounded-full border ${v.border} ${v.color} opacity-70`}>
                {t.documents.risk} {v.riesgo}
              </span>
            </div>
            <p className="text-sm font-semibold text-foreground mt-1">{resumenCorto}</p>
            <p className="text-xs text-muted-foreground mt-1 leading-relaxed">{analysis.resumen_ejecutivo}</p>
          </div>
        </div>
      </div>
    </div>
  );
}