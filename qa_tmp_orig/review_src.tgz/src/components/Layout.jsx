import { Outlet, Link, useLocation } from 'react-router-dom';
import { useState, useEffect } from 'react';
import {
  LayoutDashboard, MessageSquare, Mail, FileSearch, Calculator,
  Truck, Users, Package, Building2, Bell, Menu, X, ChevronRight,
  LogOut, ChevronUp, ShieldAlert
} from 'lucide-react';
import { useLanguage } from '@/lib/LanguageContext';
import { useAuth } from '@/lib/AuthContext';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import NotificationBell from './NotificationBell';
import OperationalReadinessBanner from './OperationalReadinessBanner';
import MarketTicker from './MarketTicker';
import ProfileSelector from './ProfileSelector';
import { ToggleGroup, ToggleGroupItem } from '@/components/ui/toggle-group';
import { base44 } from '@/api/base44Client';
import { useDemo } from '@/lib/DemoContext';

const NAV_ITEMS = [
  { path: '/', label: 'dashboard', icon: LayoutDashboard },
  { path: '/chat', label: 'chat', icon: MessageSquare },
  { path: '/emails', label: 'emails', icon: Mail },
  { path: '/documentos', label: 'documents', icon: FileSearch },
  { path: '/cargas', label: 'loads', icon: Package },
  { path: '/flota', label: 'fleet', icon: Truck },
  { path: '/conductores', label: 'drivers', icon: Users },
  { path: '/brokers', label: 'brokers', icon: Building2 },
  { path: '/calculadora', label: 'calculator', icon: Calculator },
  { path: '/notificaciones', label: 'notifications', icon: Bell },
];

export default function Layout() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const location = useLocation();
  const { user, logout } = useAuth();
  const { t, locale, setLocale } = useLanguage();
  const { isDemoUser } = useDemo();

  const nonAdminOperationalEmails = new Set([
    'luisbermudezacero@gmail.com',
    'ianruizmora@gmail.com',
  ]);
  const userEmail = (user?.email || '').toLowerCase().trim();
  const showAdminPanel = user?.role === 'admin' && !nonAdminOperationalEmails.has(userEmail);

  const visibleNavItems = NAV_ITEMS;

  useEffect(() => {
    if (typeof window === 'undefined' || !user || !user.id) return;
    const createdDate = String(user.created_date || '');
    const createdDateUtc = /(?:Z|[+-]\d{2}:?\d{2})$/.test(createdDate)
      ? createdDate
      : createdDate + 'Z';
    const createdAtMs = Date.parse(createdDateUtc);
    const isNewSignup = Number.isFinite(createdAtMs) &&
      Date.now() - createdAtMs < 24 * 60 * 60 * 1000;
    const key = '_aw_signup_fired_AW-18531970204/FleXCPrCqaYdEJzZ3YRF_' + user.id;
    if (!isNewSignup || localStorage.getItem(key)) return;
    let tries = 0;
    const fire = () => {
      if (!window.gtag) { if (tries++ < 20) setTimeout(fire, 250); return; }
      if (localStorage.getItem(key)) return;
      localStorage.setItem(key, '1');
      window.gtag('event', 'conversion', {
        send_to: 'AW-18531970204/FleXCPrCqaYdEJzZ3YRF',
        transaction_id: user.id,
      });
    };
    fire();
  }, [user]);

  const persistLocale = async (nextLocale) => {
    try {
      const user = await base44.auth.me();
      const existingProfiles = await base44.entities.UserProfile.filter({ usuario: user.email });
      if (existingProfiles.length > 0) {
        await base44.entities.UserProfile.update(existingProfiles[0].id, { idioma_chat: nextLocale });
      }
    } catch (err) {
      console.error('No se pudo persistir idioma', err);
    }
  };

  const correo = user?.email || '';
  const inicial = (correo.trim()[0] || 't').toLowerCase();

  const isActive = (path) => {
    if (path === '/') return location.pathname === '/';
    return location.pathname.startsWith(path);
  };

  const isChat = location.pathname.startsWith('/chat');

  return (
    <div className="flex h-screen bg-background overflow-hidden font-inter">
      {/* Mobile overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/60 z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside className={`
        fixed lg:static inset-y-0 left-0 z-50 lg:z-auto
        w-64 flex-shrink-0 flex flex-col
        bg-card/85 backdrop-blur-xl border-r border-white/10
        transform transition-transform duration-300 ease-in-out
        ${sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
      `}>
        {/* Logo */}
        <div className="flex items-center justify-between p-5 border-b border-white/10">
          <div className="flex items-center gap-2.5">
            {/* Logotipo completo: recuadro morado (#4F1984, el del logo original) */}
            <div className="rounded-xl bg-[#4F1984] border border-white/15 shadow-lg shadow-[#4F1984]/40 px-3 py-2 flex-shrink-0">
              <img
                src="/trucky-wordmark.png"
                alt="Trucky"
                className="h-6 w-auto select-none pointer-events-none"
                draggable={false}
              />
            </div>
            {isDemoUser && (
              <span className="px-1.5 py-0.5 rounded bg-violet-500/20 text-violet-300 border border-violet-500/30 text-[9px] font-black uppercase tracking-wider">
                Demo
              </span>
            )}
          </div>
          <button
            onClick={() => setSidebarOpen(false)}
            className="lg:hidden text-muted-foreground hover:text-foreground"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Navigation */}
        <nav className="flex-1 p-3 space-y-0.5 overflow-y-auto">
          {visibleNavItems.map(({ path, label, icon: Icon }) => (
            <Link
              key={path}
              to={path}
              onClick={() => setSidebarOpen(false)}
              className={`
                flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium
                transition-all duration-150 group
                ${isActive(path)
                  ? 'bg-primary/15 text-primary border border-primary/20'
                  : 'text-muted-foreground hover:text-foreground hover:bg-muted/50'
                }
              `}
            >
              <Icon className={`w-4 h-4 flex-shrink-0 ${isActive(path) ? 'text-primary' : ''}`} />
              <span className="flex-1">{t.nav[label]}</span>
              {isActive(path) && <ChevronRight className="w-3 h-3 text-primary opacity-60" />}
            </Link>
          ))}
          {showAdminPanel && (
            <Link
              to="/admin"
              onClick={() => setSidebarOpen(false)}
              className={`
                flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium
                transition-all duration-150 group
                ${isActive('/admin')
                  ? 'bg-amber-500/15 text-amber-500 border border-amber-500/20'
                  : 'text-amber-500/70 hover:text-amber-500 hover:bg-amber-500/10'
                }
              `}
            >
              <ShieldAlert className={`w-4 h-4 flex-shrink-0 ${isActive('/admin') ? 'text-amber-500' : ''}`} />
              <span className="flex-1">Panel Admin</span>
              {isActive('/admin') && <ChevronRight className="w-3 h-3 text-amber-500 opacity-60" />}
            </Link>
          )}
        </nav>

        {/* Botón de Idioma */}
        <div className="px-4 pb-4">
          <ToggleGroup
            type="single"
            value={locale}
            onValueChange={(val) => {
              if (val) {
                setLocale(val);
                persistLocale(val);
              }
            }}
            className="justify-start bg-muted/20 p-1 rounded-lg w-full"
          >
            <ToggleGroupItem value="es" size="sm" className="text-xs px-3 h-7 flex-1">ES</ToggleGroupItem>
            <ToggleGroupItem value="en" size="sm" className="text-xs px-3 h-7 flex-1">EN</ToggleGroupItem>
          </ToggleGroup>
        </div>

        {/* Perfil */}
        <div className="p-4 border-t border-white/10">
          <DropdownMenu>
            <DropdownMenuTrigger
              aria-label={t.nav.openProfile}
              className="w-full flex items-center gap-2 rounded-lg p-1.5 -m-1.5 text-left transition-colors hover:bg-muted/50 focus:outline-none focus-visible:ring-2 focus-visible:ring-primary/50"
            >
              <div className="w-7 h-7 rounded-full bg-[#5B2BA0] border border-white/20 flex items-center justify-center flex-shrink-0">
                <span className="text-xs font-bold text-white">{inicial}</span>
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-xs font-medium text-foreground truncate">{t.nav.profile}</div>
                <div className="text-[10px] text-muted-foreground truncate">
                  {correo || t.nav.activeSession}
                </div>
              </div>
              <ChevronUp className="w-3.5 h-3.5 text-muted-foreground flex-shrink-0" />
            </DropdownMenuTrigger>

            <DropdownMenuContent align="start" side="top" className="w-56">
              <DropdownMenuLabel className="font-normal">
                <div className="text-xs font-medium text-foreground">{t.nav.account}</div>
                <div className="text-[10px] text-muted-foreground truncate">
                  {correo || t.nav.noEmail}
                </div>
              </DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem onSelect={() => logout()} className="text-sm">
                <LogOut className="w-4 h-4 mr-2" />
                {t.nav.logout}
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </aside>

      {/* Main content */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Top bar */}
        <header className="flex flex-wrap items-center gap-3 px-4 py-3 border-b border-white/10 bg-card/55 backdrop-blur-xl flex-shrink-0 min-w-0 max-w-full overflow-hidden">
          <button
            onClick={() => setSidebarOpen(true)}
            className="lg:hidden p-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted"
          >
            <Menu className="w-5 h-5" />
          </button>
          <div className="lg:hidden text-sm font-semibold text-foreground">
            {t.nav[NAV_ITEMS.find(item => isActive(item.path))?.label] || 'Trucky'}
          </div>
          {!isChat && <MarketTicker />}
          <div className="ml-auto flex items-center gap-3">
            <ProfileSelector />
            <NotificationBell />
          </div>
        </header>

        {/* Operational readiness banner (no bloqueante) */}
        <OperationalReadinessBanner />

        {/* Page content */}
        <main className="flex-1 overflow-y-auto overflow-x-hidden min-w-0">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
