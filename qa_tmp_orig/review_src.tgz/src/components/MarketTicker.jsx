import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useLanguage } from '@/lib/LanguageContext';

function buildItems(res, isEn) {
  const items = [];
  if (res.diesel) items.push({ label: isEn ? 'DIESEL' : 'DIÉSEL', value: `$${parseFloat(res.diesel).toFixed(2)}/gal` });
  if (res.dry_van) items.push({ label: 'DRY VAN', value: `$${parseFloat(res.dry_van).toFixed(2)}/mi` });
  if (res.reefer) items.push({ label: 'REEFER', value: `$${parseFloat(res.reefer).toFixed(2)}/mi` });
  if (res.flatbed) items.push({ label: 'FLATBED', value: `$${parseFloat(res.flatbed).toFixed(2)}/mi` });
  if (res.step_deck) items.push({ label: 'STEP DECK', value: `$${parseFloat(res.step_deck).toFixed(2)}/mi` });
  if (res.power_only) items.push({ label: 'POWER ONLY', value: `$${parseFloat(res.power_only).toFixed(2)}/mi` });
  if (res.container) items.push({ label: isEn ? 'CONTAINER' : 'CONTENEDOR', value: `$${parseFloat(res.container).toFixed(2)}/mi` });
  return items;
}

function useMarketTickerData() {
  const { locale } = useLanguage();
  const isEn = locale === 'en';
  // Guardamos los datos crudos y armamos las etiquetas al vuelo: así,
  // al cambiar ES/EN, el ticker se traduce sin volver a pedir los datos.
  const [raw, setRaw] = useState(null);

  useEffect(() => {
    base44.entities.GlobalMarketTicker.filter().then(records => {
      const res = records.find(r => r.id === 'global') || records[0];
      if (res) setRaw(res);
    }).catch(err => console.error('[MarketTicker] fetch error:', err));

    const onUpdated = (e) => {
      if (e.detail) setRaw(e.detail);
    };
    window.addEventListener('tickerUpdated', onUpdated);
    return () => window.removeEventListener('tickerUpdated', onUpdated);
  }, []);

  return raw ? buildItems(raw, isEn) : [];
}

function TickerItem({ item }) {
  return (
    <div className="flex items-center gap-1.5 px-3 flex-shrink-0">
      <span className="text-[10px] font-mono uppercase tracking-wide text-muted-foreground">{item.label}</span>
      <span className="text-[11px] font-mono font-bold text-cyan-400">{item.value}</span>
      <span className="text-muted-foreground/40 ml-1">·</span>
    </div>
  );
}

function LiveBadge() {
  return (
    <div className="flex items-center gap-1.5 px-3 flex-shrink-0">
      <span className="trucky-blink w-1.5 h-1.5 rounded-full bg-red-500 inline-block shadow-sm shadow-red-500/50" />
      <span className="text-[10px] font-mono uppercase tracking-wide text-red-500 font-bold">Live</span>
      <span className="text-muted-foreground/40 ml-1">·</span>
    </div>
  );
}

export default function MarketTicker() {
  const [paused, setPaused] = useState(false);
  const items = useMarketTickerData();

  if (items.length === 0) return null;

  return (
    <div
      className="flex items-center order-last basis-full lg:order-none lg:basis-auto lg:flex-1 lg:w-0 lg:mx-4 min-w-0 h-8 rounded-lg bg-background/40 border border-border/60 overflow-hidden relative"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
      onTouchStart={() => setPaused(true)}
      onTouchEnd={() => setPaused(false)}
      title={paused ? 'Cinta en pausa' : 'Cinta de mercado en vivo'}
    >
      <div
        className="absolute left-0 top-0 bottom-0 flex items-center flex-shrink-0 animate-trucky-ticker"
        style={{ animationPlayState: paused ? 'paused' : 'running', willChange: 'transform' }}
      >
        {/* Dos copias idénticas para un loop continuo y sin saltos */}
        {[0, 1].map((copy) => (
          <div key={copy} className="flex items-center flex-shrink-0">
            <LiveBadge />
            {items.map((item, i) => (
              <TickerItem key={i} item={item} />
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}
