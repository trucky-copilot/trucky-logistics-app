import { createClientFromRequest } from 'npm:@base44/sdk@0.8.48';

export default async function adminUpdateTicker(req: Request, ctx: any) {
  const base44 = createClientFromRequest(req);
  let user;
  try {
    user = await base44.auth.me();
  } catch (e) {}
  // Acceso por el rol de la plataforma (App Users), nunca por una lista de
  // correos escrita en el código.
  if (!user || user.role !== 'admin') {
    return new Response('Unauthorized', { status: 403 });
  }

  const body = await req.json();
  const { dry_van, reefer, flatbed, step_deck, power_only, container, diesel } = body;

  const existingRecords = await base44.entities.GlobalMarketTicker.filter();
  const existing = existingRecords.find((r: any) => r.id === 'global') || existingRecords[0];

  if (existing) {
    await base44.entities.GlobalMarketTicker.update(existing.id, {
      dry_van: dry_van ?? null,
      reefer: reefer ?? null,
      flatbed: flatbed ?? null,
      step_deck: step_deck ?? null,
      power_only: power_only ?? null,
      container: container ?? null,
      diesel: diesel ?? null
    });
  } else {
    await base44.entities.GlobalMarketTicker.create({
      id: 'global',
      dry_van: dry_van ?? null,
      reefer: reefer ?? null,
      flatbed: flatbed ?? null,
      step_deck: step_deck ?? null,
      power_only: power_only ?? null,
      container: container ?? null,
      diesel: diesel ?? null
    });
  }

  return Response.json({ success: true });
}